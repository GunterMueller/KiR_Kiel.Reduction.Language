#define OFFSETS        5
#define VEKTORLAENGE   0
#define STELLIGKEIT    1
#define NAMELIST       2
#define OPAT           3
#define CODELAENGE     4  
