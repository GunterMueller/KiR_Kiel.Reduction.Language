#include "cparm.h"
/* (C) Copyright by Christian-Albrechts-University of Kiel 1993		*/
#include "cestack.h"

reduce ( stack, top, p_parms)
STACKELEM      *stack;
int            *top;
PTR_UEBERGABE  p_parms;
{
 return(1);
}

