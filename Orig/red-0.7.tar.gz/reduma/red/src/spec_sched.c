/***************************************************************************/
/*                                                                         */
/*   file     : spec_sched.c                                               */
/*                                                                         */
/*   contents : functions for time-slicing scheduling                      */
/*                                                                         */
/*   last change:                                                          */
/*                                                                         */
/*         13.09.1994                                                      */
/*                                                                         */
/***************************************************************************/

/* includes */

#include "spec_sched.h"

/* variables */

int ts_counter=0;
