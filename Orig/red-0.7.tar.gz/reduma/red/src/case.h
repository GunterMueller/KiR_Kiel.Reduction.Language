/* $Log: case.h,v $
 * Revision 1.1  1994/03/10  08:54:04  mah
 * Initial revision
 *
 * Revision 1.1  1994/03/08  15:08:07  mah
 * Initial revision
 *
 * Revision 1.1  1994/03/08  14:27:28  mah
 * Initial revision
 * */
/* $Log: case.h,v $
 * Revision 1.1  1994/03/10  08:54:04  mah
 * Initial revision
 *
 * Revision 1.1  1994/03/08  15:08:07  mah
 * Initial revision
 *
 * Revision 1.1  1994/03/08  14:27:28  mah
 * Initial revision
 * */

#define OFFSETS        5
#define VEKTORLAENGE   0
#define STELLIGKEIT    1
#define NAMELIST       2
#define OPAT           3
#define CODELAENGE     4  

#define WHEN_WITHOUT_CASE 42
