#ifndef _DBHexport_h
#define _DBHexport_h

#include "GLobal.h"

extern INT4 DBHinit();
extern void DBHrun();

#endif /* _DBHexport_h */
