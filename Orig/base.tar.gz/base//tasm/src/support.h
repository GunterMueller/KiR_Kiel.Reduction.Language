#ifndef SUPPORT_H
#define SUPPORT_H

#ifndef _MYTYPES
#include "mytypes.h"
#endif

extern int get_ia_arity(IACTION iaction);

#endif /* SUPPORT_H */
