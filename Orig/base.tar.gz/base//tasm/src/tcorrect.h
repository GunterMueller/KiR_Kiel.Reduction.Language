#ifndef _TCORRECT
#define _TCORRECT

extern int correct_t_frame();

#endif
