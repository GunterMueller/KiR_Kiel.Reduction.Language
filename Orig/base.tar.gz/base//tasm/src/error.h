extern int yywarn(const char *, ...);
extern int yyerror(const char *, ...);
extern int yyfail(const char *, ...);
extern int yymessage(const char *, ...);
