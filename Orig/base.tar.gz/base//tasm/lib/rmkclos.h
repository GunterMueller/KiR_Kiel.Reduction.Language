extern void f_mkdclos(int, int, int, int);
extern int f_mkbclos(int, T_PTD);
extern void f_mkgaclos(int, T_PTD, int, int);
extern void f_mkcclos(int, T_PTD);
extern void dyn_mkbclos(int);
