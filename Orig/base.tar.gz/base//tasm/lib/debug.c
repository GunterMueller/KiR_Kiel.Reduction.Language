/* just to be able to use dlred.o */
int getkey(void)
{
  return(0);
}
int co(void)
{
  return(0);
}
int li(void)
{
  return(0);
}
int cursorxy(void)
{
  return(0);
}
