extern int f_popfree_t(void);
extern void delta_reduct(int , T_PTD);
extern int f_apply(void);

