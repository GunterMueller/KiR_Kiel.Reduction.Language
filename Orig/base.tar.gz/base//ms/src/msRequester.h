#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "dbug.h"
#include "msMacros.h"

extern Widget WI_ms_requester;
extern Widget WI_ms_requester_title1;
extern Widget WI_ms_requester_title2;
extern Widget WI_ms_requester_title3;
extern Widget WI_ms_requester_action_o_k;
extern Widget WI_ms_requester_action_cancel;
extern Widget WI_ms_requester_action_help;
