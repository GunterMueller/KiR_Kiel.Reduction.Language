#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>

#include "msMacros.h"
#include "dbug.h"
